from django.db import models

# Create your models here.
from django.db import models
from django.contrib.auth.models import User

# This model stores info about each movie
class Movie(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    release_date = models.DateField()
    duration = models.IntegerField()  # in minutes

    def __str__(self):
        return self.title


# This model stores each seat and whether it's taken
class Seat(models.Model):
    seat_number = models.CharField(max_length=10)
    is_booked = models.BooleanField(default=False)

    def __str__(self):
        return self.seat_number


# This model connects a user, a movie, and a seat together
class Booking(models.Model):
    movie = models.ForeignKey(Movie, on_delete=models.CASCADE)
    seat = models.ForeignKey(Seat, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    booking_date = models.DateTimeField(auto_now_add=True)  # fills in automatically

    def __str__(self):
        return str(self.user) + " booked " + str(self.seat)
